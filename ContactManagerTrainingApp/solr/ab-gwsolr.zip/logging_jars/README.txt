This folder contains miscellaneous logging files required for
connecting logging by the Solr application to the logging system
of whichever application server or web container it is deployed
to.  See the Guidewire application for detailed instructions
for how to deploy Solr to the various supported JavaEE containers.
